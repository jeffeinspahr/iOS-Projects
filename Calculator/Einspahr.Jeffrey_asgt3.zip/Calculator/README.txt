Jeff Einspahr
Calculator App
CS 411

The app is fully functional, and thus far does not have any bugs that I know of.  There are no depenencies other than the files supplied in this zip file.